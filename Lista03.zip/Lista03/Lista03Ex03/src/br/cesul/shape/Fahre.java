package br.cesul.shape;

public class Fahre {
    private double celsius;

    public Fahre(double celsius) {
        this.celsius = celsius;
    }

    public double getCelsius() {
        return celsius;
    }

    public double converterCparaF() {
        double fahrenheit = (celsius * 1.8) + 32;
        return fahrenheit;
    }


}


