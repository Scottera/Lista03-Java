package br.cesul.shape;

public class Celsius {
    private double fahrenehit;

    public Celsius(double celsius) {
        this.fahrenehit = celsius;
    }

    public double converterFparaC () {
        double celsius = ((fahrenehit - 32) / 1.8);
        return celsius;
    }
    public double getCelsius() {
        return fahrenehit;
    }
}
