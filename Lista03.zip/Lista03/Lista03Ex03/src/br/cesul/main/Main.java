package br.cesul.main;

import br.cesul.shape.Fahre;
import br.cesul.shape.Celsius;
public class Main {
    public static void main(String[] args) {
        Celsius celsius = new Celsius(200);
        System.out.println("Temperatura convertida de Fahrenheit para Celsius é " + celsius.converterFparaC());

        Fahre fahre = new Fahre(999);
        System.out.println("Temperatura convertida de Celsius para Fahrenheit é " + fahre.converterCparaF());
    }
}
