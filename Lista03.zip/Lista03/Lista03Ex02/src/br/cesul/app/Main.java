package br.cesul.app;

import br.cesul.shape.Eleicao;

public class Main {
    public static void main(String[] args) {
        Eleicao eleicao = new Eleicao(100,100, 0, 0);
        System.out.println(eleicao.votacaoApurada());
    }
}
