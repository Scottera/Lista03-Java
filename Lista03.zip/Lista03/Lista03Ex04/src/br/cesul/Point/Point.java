package br.cesul.Point;

public class Point {
    private double a;
    private double b;

    public Point(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public int checkQuadrant() {
        if (a >= 0 && b >= 0) {
            return 1;
        } else if (a < 0 && b >= 0) {
            return 2;
        } else if (a < 0 && b < 0) {
            return 3;
        }
        return 4;
    }

    public static double calculateDistance(Point x, Point y) {
        return Math.sqrt(Math.abs(Math.pow(((y.a) - (x.a)), 2) + Math.pow(((y.b) - (x.b)), 2)));
    }
}