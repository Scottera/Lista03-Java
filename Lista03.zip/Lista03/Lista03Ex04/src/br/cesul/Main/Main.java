package br.cesul.Main;

import br.cesul.Point.Point;

public class Main {

    public static void main(String[] args) {

        Point x = new Point(3, 4);
        Point  y = new Point(6, 0);

        System.out.println(Point.calculateDistance(x, y));
    }
}