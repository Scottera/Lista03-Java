package br.cesul.shape;

public class Perimetro {
    private double lado;

    public Perimetro(double lado) {
        this.lado = lado;
    }
    public double calcularPerimetro () {
        double perimetro = 4 * lado;
        return perimetro;
    }

    public double getLado() {return lado;}
}