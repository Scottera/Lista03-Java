package br.cesul.shape;

public class Area {
    private double lado;

    public Area(double lado) {
        this.lado = lado;
    }

    public double calcularArea (){
        double area = lado * lado;
        return area;
    }

    public double getLado() {
        return lado;
    }
}
