package br.cesul.app;

import br.cesul.shape.Perimetro;
import br.cesul.shape.Area;

public class Main {
    public static void main(String[] args) {
        Perimetro perimetro = new Perimetro(2);
        System.out.println("O perímetro é de " + perimetro.calcularPerimetro());

        Area area = new Area(10);
        System.out.println("A área total é de " + area.calcularArea());
    }
}


