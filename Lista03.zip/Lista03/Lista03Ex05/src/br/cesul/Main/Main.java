package br.cesul.Main;

import br.cesul.Contact.Contact;
import br.cesul.Contact.ContactBook;

public class Main {
    public static void main(String[] args) {
        Contact contact = new Contact("Lucas Scotti", "Rua Salgado Filho", "M","lucas_scotti.13@hotmail.com");
        ContactBook contactBook = new ContactBook();

        Contact contact2 = new Contact("Janice", "Rua Itapejara", "f","nicescotti@hotmail.com");

        Contact contact3 = new Contact("Belonir", "Rua Barracão", "f","belonirscotti@hotmail.com");

        contactBook.insertContact(contact2);
        contactBook.insertContact(contact3);

        contactBook.insertContact(contact);

        contactBook.listContacts();

        System.out.println("Contatos após remoção!");

        contactBook.removeContact("belonir");

        contactBook.listContacts();



    }
}
