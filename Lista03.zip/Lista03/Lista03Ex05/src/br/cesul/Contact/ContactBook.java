package br.cesul.Contact;

import java.util.ArrayList;
import java.util.List;

public class ContactBook {

    List<Contact> contacts = new ArrayList<>();

    public void insertContact(Contact contact){

        contacts.add(contact);
    }


    public void removeContact(String name){
        for (Contact contact : contacts) {
            if(contact.getName().equalsIgnoreCase(name)){
                contacts.remove(contact);
            }
        }
    }

    public void listContacts(){
        for (Contact contact : contacts) {
            System.out.println("---------------------------");
            System.out.println("Name: " + contact.getName());
            System.out.println("Sex: " + contact.getSex());
            System.out.println("Email: " + contact.getEmail());
            System.out.println("Address: " + contact.getAddress());
            System.out.println("---------------------------");
        }
    }

}